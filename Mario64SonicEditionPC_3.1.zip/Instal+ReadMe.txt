Drag all the folders into your branch(ex-nightly) and click replace files. Go to the patches page, click Add Custom Patch, 
double-click the Sonic.3.1.PC file and select it on the
custom patches list.
When compiling again select the patch on the custom patches list and click Yes when asked about us_pc
folder removal.

If Sonic has Marios voice then the build hasnt been replaced or the folders havent been included.

For further questions go to the PC Port discord: https://discord.gg/Dc7Fh92q 
or ask Thodds: https://twitter.com/ThoddsGame



This mod was created by Thodds aka Theison
Twitter: https://twitter.com/ThoddsGame